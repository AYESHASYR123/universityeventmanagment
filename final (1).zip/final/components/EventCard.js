import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

const EventCard = ({ event, setSelectedEvent, setRegisterModalVisible, setFeedbackModalVisible, darkMode }) => {
  return (
    <View style={[styles.card, darkMode && styles.cardDark]}>
      <Text style={[styles.cardTitle, darkMode && styles.textDark]}>{event.name}</Text>
      <Text style={[styles.cardText, darkMode && styles.textDark]}>Date: {event.date}</Text>
      <Text style={[styles.cardText, darkMode && styles.textDark]}>Time: {event.time}</Text>
      <Text style={[styles.cardText, darkMode && styles.textDark]}>Venue: {event.venue}</Text>
      <Text style={[styles.cardText, darkMode && styles.textDark]}>{event.description}</Text>
      {event.status === "upcoming" && (
        <TouchableOpacity
          style={styles.button}
          onPress={() => {
            setSelectedEvent(event);
            setRegisterModalVisible(true);
          }}
        >
          <Text style={styles.buttonText}>Register</Text>
        </TouchableOpacity>
      )}
      {event.status === "completed" && (
        <TouchableOpacity
          style={styles.button}
          onPress={() => {
            setSelectedEvent(event);
            setFeedbackModalVisible(true);
          }}
        >
          <Text style={styles.buttonText}>Provide Feedback</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  card: { padding: 15, marginVertical: 10, borderWidth: 1, borderColor: "#ccc", borderRadius: 10 },
  cardDark: { backgroundColor: "#444" },
  cardTitle: { fontSize: 18, fontWeight: "bold", marginBottom: 10 },
  cardText: { fontSize: 14, marginBottom: 5 },
  button: { backgroundColor: "#007bff", padding: 10, borderRadius: 5, marginTop: 10 },
  buttonText: { color: "#fff", textAlign: "center", fontSize: 16 }
});

export default EventCard;
