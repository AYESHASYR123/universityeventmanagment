import React from "react";
import { Modal, TextInput, TouchableOpacity, Text, View, StyleSheet } from "react-native";

const FeedbackModal = ({ feedbackModalVisible, setFeedbackModalVisible, feedbackText, setFeedbackText, handleFeedbackSubmit, selectedEvent }) => {
  return (
    <Modal animationType="slide" transparent={true} visible={feedbackModalVisible} onRequestClose={() => setFeedbackModalVisible(false)}>
      <View style={styles.modalView}>
        <Text style={styles.modalTitle}>Provide Feedback for {selectedEvent?.name}</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your feedback"
          value={feedbackText}
          onChangeText={setFeedbackText}
        />
        <TouchableOpacity style={styles.button} onPress={handleFeedbackSubmit}>
          <Text style={styles.buttonText}>Submit Feedback</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => setFeedbackModalVisible(false)}>
          <Text style={styles.buttonText}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalView: { flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "rgba(0,0,0,0.5)" },
  modalTitle: { fontSize: 18, fontWeight: "bold", marginBottom: 10 },
  input: { borderWidth: 1, borderColor: "#ccc", padding: 10, width: "80%", marginBottom: 10, borderRadius: 5 },
  button: { backgroundColor: "#007bff", padding: 10, borderRadius: 5, marginVertical: 5 },
  buttonText: { color: "#fff", textAlign: "center", fontSize: 16 }
});

export default FeedbackModal;
