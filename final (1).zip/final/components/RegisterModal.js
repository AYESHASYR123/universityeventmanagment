import React from "react";
import { Modal, TextInput, TouchableOpacity, Text, View, StyleSheet } from "react-native";

const RegisterModal = ({ registerModalVisible, setRegisterModalVisible, selectedEvent, userDetails, setUserDetails, handleRegister }) => {
  return (
    <Modal animationType="slide" transparent={true} visible={registerModalVisible} onRequestClose={() => setRegisterModalVisible(false)}>
      <View style={styles.modalView}>
        <Text style={styles.modalTitle}>Register for {selectedEvent?.name}</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your name"
          value={userDetails.name}
          onChangeText={(text) => setUserDetails({ ...userDetails, name: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="Enter your email"
          value={userDetails.email}
          onChangeText={(text) => setUserDetails({ ...userDetails, email: text })}
        />
        <TouchableOpacity style={styles.button} onPress={handleRegister}>
          <Text style={styles.buttonText}>Register</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => setRegisterModalVisible(false)}>
          <Text style={styles.buttonText}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalView: { flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "rgba(0,0,0,0.5)" },
  modalTitle: { fontSize: 18, fontWeight: "bold", marginBottom: 10 },
  input: { borderWidth: 1, borderColor: "#ccc", padding: 10, width: "80%", marginBottom: 10, borderRadius: 5 },
  button: { backgroundColor: "#007bff", padding: 10, borderRadius: 5, marginVertical: 5 },
  buttonText: { color: "#fff", textAlign: "center", fontSize: 16 }
});

export default RegisterModal;
