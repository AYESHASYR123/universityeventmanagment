import React from "react";
import { View, Text, StyleSheet } from "react-native";

const RegisteredEventCard = ({ event, darkMode }) => {
  return (
    <View style={[styles.card, darkMode && styles.cardDark]}>
      <Text style={[styles.cardTitle, darkMode && styles.textDark]}>
        {event.name} (Registered)
      </Text>
      <Text style={[styles.cardText, darkMode && styles.textDark]}>Date: {event.date}</Text>
      <Text style={[styles.cardText, darkMode && styles.textDark]}>Time: {event.time}</Text>
      <Text style={[styles.cardText, darkMode && styles.textDark]}>Venue: {event.venue}</Text>
      <Text style={[styles.cardText, darkMode && styles.textDark]}>{event.description}</Text>
      {event.feedback && (
        <Text style={[styles.cardText, darkMode && styles.textDark]}>
          Feedback: {event.feedback}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  card: { padding: 15, marginVertical: 10, borderWidth: 1, borderColor: "#ccc", borderRadius: 10 },
  cardDark: { backgroundColor: "#444" },
  cardTitle: { fontSize: 18, fontWeight: "bold", marginBottom: 10 },
  cardText: { fontSize: 14, marginBottom: 5 }
});

export default RegisteredEventCard;
